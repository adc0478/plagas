function menu_sector(){
	this.menu_lab = [
      'Laboratorio'
	];
	
	this.menu_ester =[
      'Esterilizador'
	];
	
	this.menu_tetra = [
       'Mid',
       'Speed',
       'Flex',
       'Prisma',
       'TBA8B'
	];
    
    this.menu_serac = [
       'Serac'
    ];

    this.menu_carga = [
       'Carga'
    ];

    this.menu_choco = [
       'Chocolateria'
    ];

    
}