function menu_subsector(){
	this.menu_lab = [
      'Laboratorio'
	];
    
    this.menu_ester = [
      'Esterilizador'
    ];
    
    this.menu_maquina = [
       'Linea',
       'Maquina',
    ];
    this.menu_choco = [
       'Chocolateria'
    ]

    this.menu_carga = [
       'Carga'
    ]
}