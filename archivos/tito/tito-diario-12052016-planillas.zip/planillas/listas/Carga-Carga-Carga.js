	lista = [
       'lab.pdf'
	];