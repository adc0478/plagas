function lista (){
	//en lista se carga las referencias 
	this.lista = [

	];
}