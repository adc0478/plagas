function combo (lista,padre,ref){


    var nodo = new nodos();
   
    var long = lista.length;
    //Cargo un valor vacio///
           nodo.crear ("option",ref,ref,padre);
           nodo.atributos(ref,"value","");
           nodo.crearTexto(ref," ");
    for (i=0; i< long; i++) {

    	   nodo.crear ("option",ref+i,ref,padre);
           nodo.atributos(ref + i,"value",lista[i]);
           nodo.crearTexto(ref + i,lista[i]);
        }
}
function buscar(){
   var nodo = new nodos();
   if (document.getElementById('subsector').value != ""){
      if (document.getElementById('sector').value != ""){
         var ruta1 = document.getElementById('area').value;
         var ruta2 = document.getElementById('sector').value;
         var ruta3 = document.getElementById('subsector').value;
         var total = 'listas/'+ruta1 + '-' + ruta2 + '-' + ruta3 + '.js';
         nodo.atributos('listas_arc','src',total);
         var lis = lista;
         nodo.borrar ('listaDiv','archivos');
         nodo.crear('div','listaDiv','listaDiv','archivos');
         var j=0;
         var longitud = lis.length;
         var valor;
         for (j=0; j<longitud;j++ ){
         	  valor = lis[j];
              nodo.crear('a','l'+j,'l' + j,'listaDiv');
              nodo.atributos('l'+j,'href','planillas/' + valor);
              nodo.crearTexto('l'+j,valor);
         }

      }
	}
}
function listar (){
	var nodo = new nodos();
	nodo.borrar ('listas_arc','body');
	nodo.crear('script','listas_arc','listas_arc','body')
}


function cargar_area(){
  //leer el archivo y listar el resultado
    var dato;
    var nodo = new nodos();
    var area = new menu_area();
    dato = area.menu;	
    var j = 0;
    var long = dato.length;
    for (i=0; i< long; i++) {

    	   nodo.crear ("option","id_area" + i,"cl_area","area");
           nodo.atributos("id_area" + i,"value",dato[i]);
           nodo.crearTexto("id_area" + i,dato[i]);
        }
}
function cargar_sector(){
	var sector = new menu_sector();
    var parametro = document.getElementById('area').value;
    var lista;
    document.getElementById('sector').options.length =0;
    document.getElementById('subsector').options.length =0;
    switch (parametro){
    	case 'Laboratorio':
            lista = sector.menu_lab;
            break;
    	case 'Tetra':
            lista = sector.menu_tetra;
            break;
    	case 'Chocolateria':
            lista = sector.menu_choco;
            break;
    	case 'Esterilizador':
            lista  = sector.menu_ester;
            break;
    	case 'Serac':
            lista  = sector.menu_serac;
            break;
    	case 'Carga':
    	    lista  = sector.menu_carga;
    	    break;

    };

    combo (lista,'sector','sector');

}
function cargar_subsector(){
   var parametro = document.getElementById('sector').value;
   	var sector = new menu_subsector();
    var lista;
    document.getElementById('subsector').options.length =0;
    switch (parametro){
    	case 'Laboratorio':
            lista = sector.menu_lab;
            break;
    	case 'Mid':
    	case 'Speed':
    	case 'Serac':
    	case 'Flex':
    	case 'Prisma':
    	case'TBA8B':
            lista = sector.menu_maquina;
            break;
    	case 'Chocolateria':
            lista = sector.menu_choco;
            break;
    	case 'Esterilizador':
            lista  = sector.menu_ester;
            break;
    	case 'Carga':
    	    lista  = sector.menu_carga;
    	    break;

    };

    combo (lista,'subsector','subsector');
}



function inicio(){
	cargar_area();
	document.getElementById('area').onchange = cargar_sector;
	document.getElementById('sector').onchange = cargar_subsector;
    document.getElementById('subsector').onchange = listar;
    document.getElementById('btn').onclick = buscar;
}


window.onload = inicio;