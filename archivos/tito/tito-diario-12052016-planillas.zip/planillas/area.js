function menu_area (){
	this.menu =  [
        "Laboratorio",
        "Esterilizador",
        "Tetra",
        "Serac",
        "Carga",
        "Chocolateria"
	]
}